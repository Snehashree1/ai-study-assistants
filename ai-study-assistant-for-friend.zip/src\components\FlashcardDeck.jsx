import { useState } from "react";
import Flashcard from "./Flashcard";

function FlashcardDeck({ cards }) {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);

    const currentCard = cards[currentIndex];
    if (!cards || cards.length === 0) {
        return null;
    }

    const goNext = () => {
        setIsFlipped(false);

        setCurrentIndex((index) =>
            index === cards.length - 1 ? 0 : index + 1
        );
    };

    const goPrevious = () => {
        setIsFlipped(false);

        setCurrentIndex((index) =>
            index === 0 ? cards.length - 1 : index - 1
        );
    };

    return (
        <section className="flashcards-section">
            <div className="section-heading">
                <div>
                    <span className="section-label">LEARN</span>

                    <h2>Flashcards</h2>

                    <p>Click the card to reveal the answer.</p>
                </div>

                <div className="card-progress">
                    {currentIndex + 1} / {cards.length}
                </div>
            </div>

            <Flashcard
                card={currentCard}
                isFlipped={isFlipped}
                onFlip={() => setIsFlipped(!isFlipped)}
            />

            <div className="flashcard-controls">
                <button
                    type="button"
                    onClick={goPrevious}
                    className="secondary-button"
                >
                    ← Previous
                </button>

                <button
                    type="button"
                    onClick={goNext}
                    className="primary-button"
                >
                    Next →
                </button>
            </div>
        </section>
    );
}

export default FlashcardDeck;