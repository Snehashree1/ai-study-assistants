import { useRef, useState } from "react";
import "./App.css";
import FlashcardDeck from "./components/FlashcardDeck";
import Quiz from "./components/Quiz";

function App() {
  const requestIdRef = useRef(0);

  const [topic, setTopic] = useState("");
  const [cards, setCards] = useState([]);
  const [quiz, setQuiz] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const hasStudySet = cards.length > 0 || quiz.length > 0;

  const handleGenerate = async () => {
    if (!topic.trim()) return;

    const requestId = ++requestIdRef.current;

    setLoading(true);
    setError("");
    setCards([]);
    setQuiz([]);

    try {
      const response = await fetch("http://localhost:3001/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          topic: topic,
        }),
      });

      const data = await response.json();

      if (requestId !== requestIdRef.current) {
        return;
      }

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate study set.");
      }

      if (!data.cards || !Array.isArray(data.cards)) {
        throw new Error("AI returned invalid flashcard data.");
      }

      if (!data.quiz || !Array.isArray(data.quiz)) {
        throw new Error("AI returned invalid quiz data.");
      }

      setCards(data.cards);
      setQuiz(data.quiz);
    } catch (error) {
      console.error("Generation error:", error);

      setError(
        error.message === "Failed to fetch"
          ? "Unable to connect to the AI service. Make sure the backend server is running and try again."
          : error.message || "Something went wrong."
      );
    } finally {
      if (requestId === requestIdRef.current) {
        setLoading(false);
      }
    }
  };

  const handleExample = (example) => {
    setTopic(example);
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand">
            <div className="brand-mark">A</div>

            <div>
              <div className="brand-name">StudyAI</div>
              <div className="brand-subtitle">AI Study Assistant</div>
            </div>
          </div>

          <div className="topbar-status">
            <span className="status-dot"></span>
            AI powered learning
          </div>
        </div>
      </header>

      <main>
        {!hasStudySet && !loading && (
          <section className="hero-section">
            <div className="hero-content">
              <div className="eyebrow">
                <span>✦</span>
                LEARN SOMETHING NEW
              </div>

              <h1>
                Turn any topic into
                <span> a study session.</span>
              </h1>

              <p className="hero-text">
                Enter a topic and let AI create interactive flashcards and
                quiz questions to help you learn, practice, and remember.
              </p>

              <div className="generator">
                <textarea
                  value={topic}
                  onChange={(event) => setTopic(event.target.value)}
                  placeholder="What would you like to study?"
                  rows={3}
                  onKeyDown={(event) => {
                    if (
                      event.key === "Enter" &&
                      !event.shiftKey &&
                      topic.trim()
                    ) {
                      event.preventDefault();
                      handleGenerate();
                    }
                  }}
                />

                <div className="generator-bottom">
                  <span className="input-hint">
                    Press Enter to generate · Shift + Enter for a new line
                  </span>

                  <button
                    className="generate-button"
                    onClick={handleGenerate}
                    disabled={!topic.trim() || loading}
                  >
                    {loading ? (
                      <>
                        <span className="button-spinner"></span>
                        Creating...
                      </>
                    ) : (
                      <>
                        Generate
                        <span>→</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="examples">
                <span className="examples-label">Try an example</span>

                <div className="example-list">
                  {[
                    "Machine Learning basics",
                    "Photosynthesis",
                    "World War II",
                    "Python programming",
                  ].map((example) => (
                    <button
                      key={example}
                      type="button"
                      className="example-chip"
                      onClick={() => handleExample(example)}
                    >
                      {example}
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div className="error-message">
                  <span className="error-icon">!</span>
                  <div>
                    <strong>Something went wrong</strong>
                    <p>{error}</p>
                  </div>
                </div>
              )}

              <div className="feature-row">
                <div className="mini-feature">
                  <span>◇</span>
                  AI-generated
                </div>

                <div className="mini-feature">
                  <span>◇</span>
                  Interactive
                </div>

                <div className="mini-feature">
                  <span>◇</span>
                  Retest mistakes
                </div>
              </div>
            </div>
          </section>
        )}

        {loading && (
          <section className="loading-section">
            <div className="loading-card">
              <div className="loading-animation">
                <div className="loading-ring"></div>
                <span>✦</span>
              </div>

              <h2>Building your study session</h2>

              <p>
                AI is creating flashcards and quiz questions for{" "}
                <strong>{topic}</strong>.
              </p>

              <div className="loading-progress">
                <span></span>
              </div>
            </div>
          </section>
        )}

        {hasStudySet && !loading && (
          <section className="study-session">
            <div className="session-header">
              <div>
                <div className="session-eyebrow">YOUR STUDY SESSION</div>

                <h1>{topic}</h1>

                <p>
                  Learn the concepts first, then test what you remember.
                </p>
              </div>

              <button
                type="button"
                className="new-topic-button"
                onClick={() => {
                  setCards([]);
                  setQuiz([]);
                  setError("");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              >
                + New topic
              </button>
            </div>

            <div className="session-stats">
              <div className="stat">
                <span className="stat-icon">▣</span>
                <div>
                  <strong>{cards.length}</strong>
                  <span>Flashcards</span>
                </div>
              </div>

              <div className="stat">
                <span className="stat-icon">?</span>
                <div>
                  <strong>{quiz.length}</strong>
                  <span>Quiz questions</span>
                </div>
              </div>

              <div className="stat">
                <span className="stat-icon">↻</span>
                <div>
                  <strong>1</strong>
                  <span>Retest mode</span>
                </div>
              </div>
            </div>

            <div className="learning-path">
              <div className="path-line"></div>

              <div className="path-step active">
                <div className="path-number">1</div>
                <div>
                  <strong>Learn</strong>
                  <span>Study the flashcards</span>
                </div>
              </div>

              <div className="path-step">
                <div className="path-number">2</div>
                <div>
                  <strong>Practice</strong>
                  <span>Test your knowledge</span>
                </div>
              </div>

              <div className="path-step">
                <div className="path-number">3</div>
                <div>
                  <strong>Improve</strong>
                  <span>Retest mistakes</span>
                </div>
              </div>
            </div>

            <FlashcardDeck cards={cards} />

            <Quiz questions={quiz} />
          </section>
        )}

        {!hasStudySet && !loading && (
          <section className="how-section">
            <div className="section-intro">
              <span>HOW IT WORKS</span>
              <h2>Simple to start. Easy to learn.</h2>
            </div>

            <div className="how-grid">
              <div className="how-card">
                <div className="how-number">01</div>
                <div className="how-icon">✎</div>
                <h3>Choose a topic</h3>
                <p>
                  Enter anything you want to understand or revise.
                </p>
              </div>

              <div className="how-card">
                <div className="how-number">02</div>
                <div className="how-icon">✦</div>
                <h3>AI builds your set</h3>
                <p>
                  Your topic becomes focused flashcards and quiz questions.
                </p>
              </div>

              <div className="how-card">
                <div className="how-number">03</div>
                <div className="how-icon">✓</div>
                <h3>Learn & test</h3>
                <p>
                  Study, take the quiz, and revisit the answers you missed.
                </p>
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="footer">
        <div>StudyAI</div>
        <span>Built with React, Express & Ollama</span>
      </footer>
    </div>
  );
}

export default App;