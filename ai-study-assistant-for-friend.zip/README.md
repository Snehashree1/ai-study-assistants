# AI Study Assistant

An interactive AI-powered study assistant built with React, Express, and Ollama.

The application takes a free-form study topic from the user and uses an AI model to generate structured flashcards and multiple-choice quiz questions.

## Features

- Free-form study topic input
- AI-generated flashcards
- Interactive flashcard flip
- Previous and Next navigation
- AI-generated multiple-choice quiz
- Randomized quiz answer positions
- Instant correct/incorrect feedback
- Automatic score calculation
- Retest Wrong Answers feature
- Full quiz retake
- Loading state
- Error handling
- Invalid AI response validation
- Stale-response protection
- Responsive design for smaller screens

## Tech Stack

### Frontend

- React
- Vite
- JavaScript
- CSS

### Backend

- Node.js
- Express
- CORS

### AI

- Ollama
- Gemma 3 4B

## How It Works

1. The user enters a study topic.
2. React sends the topic to the Express backend.
3. The backend sends a structured prompt to the local Ollama model.
4. Ollama returns flashcards and quiz questions as JSON.
5. The backend validates the AI-generated data.
6. Valid data is sent back to the React frontend.
7. React renders the flashcards and interactive quiz.
8. Incorrect quiz answers are stored so the user can retest them.

## Project Structure

```text
ai-study-assistant/
│
├── public/
│
├── server/
│   └── index.js
│
├── src/
│   ├── components/
│   │   ├── Flashcard.jsx
│   │   ├── FlashcardDeck.jsx
│   │   └── Quiz.jsx
│   │
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
│
├── .gitignore
├── package.json
├── package-lock.json
└── README.md
```

## Requirements

Before running the project, make sure you have:

- Node.js installed
- npm installed
- Ollama installed
- Gemma 3 4B model available in Ollama

## Installation

Clone the repository:

```bash
git clone <your-github-repository-url>
cd ai-study-assistant
```

Install dependencies:

```bash
npm install
```

Make sure the Ollama model is available:

```bash
ollama list
```

If Gemma 3 4B is not available:

```bash
ollama pull gemma3:4b
```

## Running the Application

### 1. Start the backend

Open a terminal and run:

```bash
node server/index.js
```

The backend runs at:

```text
http://localhost:3001
```

### 2. Start the frontend

Open another terminal and run:

```bash
npm run dev
```

The frontend normally runs at:

```text
http://localhost:5173
```

Open the URL shown in the terminal.

## Example

Enter a topic such as:

```text
Machine Learning basics
```

The AI generates:

- 5 flashcards
- 5 multiple-choice questions
- 4 options for each question

The user can study using the flashcards and then test their knowledge using the quiz.

## AI Usage

The application uses Ollama with the Gemma 3 4B model.

The backend sends a structured prompt requesting JSON containing:

- Flashcards
- Quiz questions
- Multiple-choice options
- Correct answer indexes

The backend parses and validates the AI-generated response before sending it to the React frontend.

No external AI API key is exposed in the frontend.

## Error Handling

The application handles:

- Empty topic input
- Backend connection failure
- AI service failure
- Invalid JSON
- Invalid flashcard structure
- Invalid quiz structure
- Empty AI results
- Older AI responses overwriting newer requests

When the backend cannot be reached, the application displays a user-friendly error message.

## Limitations

- The application currently runs locally.
- Ollama must be installed and running.
- AI-generated content depends on the model's output quality.
- The application currently generates 5 flashcards and 5 quiz questions.
- Study progress is not permanently saved after refreshing the page.

## Future Improvements

- Save study sets
- Persistent learning progress
- Difficulty selection
- More question types
- Study history
- User accounts
- Deployment with a hosted AI service

## Time Spent

Approximately: **[Add your actual time spent]**

## Author

**Atal Mahaprasad**

Built as part of a frontend internship assignment.