import express from "express";
import cors from "cors";

const app = express();

app.use(cors());
app.use(express.json());

app.post("/api/generate", async (req, res) => {
    try {
        const { topic } = req.body;

        if (!topic || !topic.trim()) {
            return res.status(400).json({
                error: "Please provide a study topic.",
            });
        }

        const prompt = `
You are an AI study assistant.

The user wants to study:
"${topic}"

Create:
1. Exactly 5 flashcards.
2. Exactly 5 multiple-choice quiz questions.

Return ONLY valid JSON.
Do not use markdown.
Do not use code fences.
Do not add explanations.

Use EXACTLY this structure:

{
  "cards": [
    {
      "question": "Question here",
      "answer": "Clear answer here"
    }
  ],
  "quiz": [
    {
      "question": "Multiple choice question here",
      "options": [
        "Option A",
        "Option B",
        "Option C",
        "Option D"
      ],
      "answerIndex": 0
    }
  ]
}

Rules:
- cards must contain exactly 5 objects.
- quiz must contain exactly 5 objects.
- Every quiz question must have exactly 4 options.
- answerIndex must be a number from 0 to 3.
- answerIndex must point to the correct option.
- Distribute correct answers across different option positions. Do not place the correct answer in the same position repeatedly.
- Across the 5 questions, use a varied mix of answerIndex values from 0 to 3.
- Questions should focus on important concepts from the topic.
- Answers should be clear and beginner-friendly.
- Answers must be concise, preferably 1-3 sentences.
- Quiz questions and options must be concise.
`;

        const response = await fetch("http://localhost:11434/api/generate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                model: "llama3.2:latest",
                prompt: prompt,
                stream: false,
                format: "json",
                options: {
                    temperature: 0.2,
                    num_predict: 900,
                },
            }),
        });

        if (!response.ok) {
            throw new Error(`Ollama returned status ${response.status}`);
        }

        const data = await response.json();

        let result;

        try {
            result = JSON.parse(data.response);
        } catch {
            return res.status(502).json({
                error: "The AI returned invalid JSON.",
            });
        }

        // Validate flashcards
        if (!Array.isArray(result.cards) || result.cards.length === 0) {
            return res.status(502).json({
                error: "The AI returned invalid flashcards.",
            });
        }

        const validCards = result.cards.filter(
            (card) =>
                card &&
                typeof card.question === "string" &&
                typeof card.answer === "string" &&
                card.question.trim() &&
                card.answer.trim()
        );

        if (validCards.length === 0) {
            return res.status(502).json({
                error: "No valid flashcards were generated.",
            });
        }

        // Validate quiz
        if (!Array.isArray(result.quiz) || result.quiz.length === 0) {
            return res.status(502).json({
                error: "The AI returned invalid quiz questions.",
            });
        }

        const validQuiz = result.quiz.filter(
            (question) =>
                question &&
                typeof question.question === "string" &&
                Array.isArray(question.options) &&
                question.options.length === 4 &&
                question.options.every(
                    (option) => typeof option === "string" && option.trim()
                ) &&
                Number.isInteger(question.answerIndex) &&
                question.answerIndex >= 0 &&
                question.answerIndex <= 3
        );

        if (validQuiz.length === 0) {
            return res.status(502).json({
                error: "No valid quiz questions were generated.",
            });
        }

        const shuffledQuiz = validQuiz.map((question) => {
            const options = question.options.map((text, index) => ({
                text,
                isCorrect: index === question.answerIndex,
            }));

            for (let i = options.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [options[i], options[j]] = [options[j], options[i]];
            }

            return {
                ...question,
                options: options.map((option) => option.text),
                answerIndex: options.findIndex((option) => option.isCorrect),
            };
        });

        res.json({
            cards: validCards,
            quiz: shuffledQuiz,
        });
    } catch (error) {
        console.error("AI generation error:", error);

        res.status(500).json({
            error:
                error.message ||
                "Something went wrong while generating the study set.",
        });
    }
});

const PORT = 3001;

app.listen(PORT, () => {
    console.log(`Backend server running on http://localhost:${PORT}`);
});