function Flashcard({ card, isFlipped, onFlip }) {
  return (
    <div className="flashcard-container">
      <button
        className={`flashcard ${isFlipped ? "flipped" : ""}`}
        onClick={onFlip}
        type="button"
        aria-label="Flip flashcard"
      >
        <div className="flashcard-inner">
          <div className="flashcard-front">
            <span className="card-label">QUESTION</span>

            <h2>{card.question}</h2>

            <span className="flip-hint">
              ↕ Click to reveal answer
            </span>
          </div>

          <div className="flashcard-back">
            <span className="card-label">ANSWER</span>

            <p>{card.answer}</p>

            <span className="flip-hint">
              ↕ Click to see question
            </span>
          </div>
        </div>
      </button>
    </div>
  );
}

export default Flashcard;