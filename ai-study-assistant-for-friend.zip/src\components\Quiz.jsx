import { useEffect, useState } from "react";

function Quiz({ questions }) {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState(null);
    const [score, setScore] = useState(0);
    const [wrongQuestions, setWrongQuestions] = useState([]);
    const [retestQuestions, setRetestQuestions] = useState([]);
    const [isRetesting, setIsRetesting] = useState(false);

    // Reset the quiz whenever a new AI-generated quiz arrives
    useEffect(() => {
        setCurrentIndex(0);
        setSelectedAnswer(null);
        setScore(0);
        setWrongQuestions([]);
        setRetestQuestions([]);
        setIsRetesting(false);
    }, [questions]);

    if (!questions || questions.length === 0) {
        return null;
    }

    // Decide which questions should currently be displayed
    const activeQuestions = isRetesting
        ? retestQuestions
        : questions;

    const currentQuestion = activeQuestions[currentIndex];

    const handleAnswer = (index) => {
        if (selectedAnswer !== null) return;

        setSelectedAnswer(index);

        if (index === currentQuestion.answerIndex) {
            setScore((value) => value + 1);
        } else {
            setWrongQuestions((previous) => [
                ...previous,
                currentQuestion,
            ]);
        }
    };

    const handleNext = () => {
        setSelectedAnswer(null);
        setCurrentIndex((index) => index + 1);
    };

    const restartQuiz = () => {
        setIsRetesting(false);
        setRetestQuestions([]);
        setCurrentIndex(0);
        setSelectedAnswer(null);
        setScore(0);
        setWrongQuestions([]);
    };

    const startWrongAnswerRetest = () => {
        setRetestQuestions([...wrongQuestions]);
        setIsRetesting(true);
        setCurrentIndex(0);
        setSelectedAnswer(null);
        setScore(0);
        setWrongQuestions([]);
    };

    const quizFinished =
        currentIndex >= activeQuestions.length;

    if (quizFinished) {
        return (
            <section className="quiz-section">
                <div className="section-heading">
                    <div>
                        <span className="section-label">
                            {isRetesting
                                ? "RETEST"
                                : "TEST YOURSELF"}
                        </span>

                        <h2>
                            {isRetesting
                                ? "Retest Complete 🎯"
                                : "Quiz Complete 🎉"}
                        </h2>

                        <p>
                            You scored {score} out of{" "}
                            {activeQuestions.length}.
                        </p>
                    </div>
                </div>

                <div className="quiz-result">
                    <div className="quiz-score">
                        {score} / {activeQuestions.length}
                    </div>

                    {!isRetesting && (
                        <>
                            <button
                                type="button"
                                className="primary-button"
                                onClick={restartQuiz}
                            >
                                Retake Quiz
                            </button>

                            {wrongQuestions.length > 0 && (
                                <button
                                    type="button"
                                    className="secondary-button"
                                    onClick={startWrongAnswerRetest}
                                >
                                    Retest Wrong Answers
                                </button>
                            )}
                        </>
                    )}

                    {isRetesting && (
                        <button
                            type="button"
                            className="primary-button"
                            onClick={restartQuiz}
                        >
                            Back to Full Quiz
                        </button>
                    )}
                </div>
            </section>
        );
    }

    return (
        <section className="quiz-section">
            <div className="section-heading">
                <div>
                    <span className="section-label">
                        {isRetesting
                            ? "RETEST WRONG ANSWERS"
                            : "TEST YOURSELF"}
                    </span>

                    <h2>
                        {isRetesting
                            ? "Practice Your Mistakes"
                            : "Quiz"}
                    </h2>

                    <p>
                        {isRetesting
                            ? "Try the questions you previously missed."
                            : "Choose the correct answer."}
                    </p>
                </div>

                <div className="card-progress">
                    {currentIndex + 1} / {activeQuestions.length}
                </div>
            </div>

            <div className="quiz-card">
                <h3>{currentQuestion.question}</h3>

                <div className="quiz-options">
                    {currentQuestion.options.map((option, index) => {
                        let className = "quiz-option";

                        if (selectedAnswer !== null) {
                            if (
                                index ===
                                currentQuestion.answerIndex
                            ) {
                                className += " correct";
                            } else if (
                                index === selectedAnswer
                            ) {
                                className += " incorrect";
                            }
                        }

                        return (
                            <button
                                key={index}
                                type="button"
                                className={className}
                                onClick={() =>
                                    handleAnswer(index)
                                }
                            >
                                {option}
                            </button>
                        );
                    })}
                </div>

                {selectedAnswer !== null && (
                    <button
                        type="button"
                        className="primary-button quiz-next"
                        onClick={handleNext}
                    >
                        {currentIndex ===
                        activeQuestions.length - 1
                            ? "See Result"
                            : "Next Question →"}
                    </button>
                )}
            </div>
        </section>
    );
}

export default Quiz;